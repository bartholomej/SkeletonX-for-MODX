SkeletonX for MODX
============
SkeletonX is basic HTML boilerplate for MODx Revolution

See more: https://github.com/bartholomej/SkeletonX-for-MODX